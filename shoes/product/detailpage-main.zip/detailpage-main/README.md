# How to make page detail product page using HTML CSS and Javascript Only

```http
Important note: If you have downloaded the code
but still encounter errors when running the program,
 please watch the video at this link because
 I have shown you how to run the project properly.
```
- [https://www.youtube.com/watch?v=okyfcpZfPAU&t=142s](https://www.youtube.com/watch?v=okyfcpZfPAU&t=142s)

![Logo](https://i.ytimg.com/vi/okyfcpZfPAU/maxresdefault.jpg)
